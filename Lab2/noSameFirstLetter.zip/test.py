print([len("... * hello".split()), "... * hello".split()])
print("fdsv".isalpha())
print(ascii('— zawołała.'))