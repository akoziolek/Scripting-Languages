import sys 

END_OF_CONTENTS_SYMBOL = "-----"
PREAMBLE_MAX_SIZE = 10
DEFAULT_UTF = "utf-8"

def is_sentence_end(sign):
    return sign == '.' or sign == '?' or sign == '!' or sign == '\n'

def is_white_sign(sign):
    return sign == ' ' or sign == '\n' or sign == '\t' or sign == '\r' or sign == '\v' or sign == '\f'

def print_text(*args):
    for el in args:
        try:
            sys.stdout.write(str(el) + '\n')
        except TypeError:
            sys.stdout.write("Wrong value type given")


#reading texts from file with option to choose the encoding
#default utf-8 set on the sys couldnt read the polish chars, but after specyfying the utf-8 problem is gone


def read_txt_contents(file_encoding=DEFAULT_UTF):
    original_stdin = sys.stdin

    try:
        sys.stdin.reconfigure(encoding=file_encoding) 
        text = ""
        idx_line = 0
        was_prev_line_empty = False
        was_Preambule = False
        
        for line in sys.stdin:
            line = line.strip()
            if line == END_OF_CONTENTS_SYMBOL:
                break

            elif line == '':

                if idx_line < PREAMBLE_MAX_SIZE and was_prev_line_empty and not was_Preambule:
                    text = ""
                    was_prev_line_empty = False 
                    was_Preambule = True 
                else:
                    if not was_prev_line_empty: text += '\n'
                    was_prev_line_empty = True

            else:
                nextLine = ""
                i = 0
                while i < len(line):
                    if is_sentence_end(line[i]) and line[i-1] == ' ':
                        nextLine = nextLine[:-1] + line[i]
                    elif line[i] != ' ' or line[i-1] != ' ': #normalny znak, lub pojedyncza spacja
                       nextLine += line[i] 
                    i += 1

                nextLine += '\n'
                was_prev_line_empty = False
                text += nextLine  

            idx_line += 1

    #finally:
        #sys.stdin = original_stdin
    except:
        raise Exception('cd')
  
    return text

#sprawdzenie czy moduł uruchamiany jest bezpośrednio czy jako importowany moduł w innym skrypcie
if __name__ == '__main__':
    print_text(read_txt_contents())

 
    
    
    
    
    