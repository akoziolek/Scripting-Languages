import text_parser
def find_longest_sentence():
    text = text_parser.read_txt_contents()
    longest_sentence = ""
    current_sentence = ""
    lastLetter = ''
    are_unique = True
    was_end = False
    
    for char in text:
       if was_end and char.isspace(): 
           was_end = True
           lastLetter = ''
           continue #skipping the space after the end of sentence
       if char != '\n':
            #if was_end == True and lastLetter != '': #tu cos
                #print(char)
            print(lastLetter)
            if are_unique and lastLetter != '': 
                are_unique = char.lower() != lastLetter.lower()
            current_sentence += char
            was_end = False
            if lastLetter == '': lastLetter = char
            

       if text_parser.is_sentence_end(char):
           was_end = True
           if(len(current_sentence) > len(longest_sentence) and are_unique): 
                longest_sentence = current_sentence
           current_sentence = ""
           are_unique = True
           lastLetter = ''

    return longest_sentence
    

if __name__ == "__main__":
    text_parser.print_text(find_longest_sentence())
